#!/bin/bash
sudo mkdir -p mnt
sudo ./jsonfsx fs.json ./mnt
