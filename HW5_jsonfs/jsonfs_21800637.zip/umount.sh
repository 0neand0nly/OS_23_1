sudo fusermount -u ./mnt
